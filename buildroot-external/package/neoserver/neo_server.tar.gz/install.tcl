#!/bin/tclsh

package require HomeMatic

set ID          mediola
set URL         /addons/mediola/index.html
set NAME        "NEO SERVER"

array set DESCRIPTION {
  de {<li>NEO SERVER</li>}
  en {<li>NEO SERVER</li>}
}

::HomeMatic::Addon::AddConfigPage $ID $URL $NAME [array get DESCRIPTION]
